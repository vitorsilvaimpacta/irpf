npm install express

npm install mysql2

npm install nodemon -d

npm install dotenv

npx eslint --init